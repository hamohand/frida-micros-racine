import { DzEidSession } from 'dz-eid';

const $ = (id: string) => document.getElementById(id)!;

const esc = (s: unknown): string =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] || c));

function frStatus(s?: string): string {
  switch (s) {
    case 'VALID': return 'Valide';
    case 'INVALID': return 'Invalide';
    case 'NOT_CHECKED': return 'Non vérifié';
    case 'NOT_SUPPORTED': return 'Non supporté';
    default: return s || '—';
  }
}

let currentRecord: any = null;
let currentFullJson = '';

function renderRecord(r: any, sessionId: string) {
  // En mode Standard (ex. Frida), toute section liveness éventuelle est ignorée
  const cleanRecord = { ...r };
  delete cleanRecord.liveness;
  currentRecord = cleanRecord;

  const h = cleanRecord.holder || {};
  const d = cleanRecord.document || {};
  const v = cleanRecord.verification || {};
  const pa = v.passiveAuthentication || {};
  const aa = v.activeAuthentication || {};

  $('empty').style.display = 'none';
  $('identity').classList.add('on');

  const nowStr = new Date().toLocaleString('fr-FR');
  $('printTimestamp').textContent = `Lecture effectuée le ${nowStr}`;
  $('printSessionId').textContent = `Session E2EE : ${sessionId}`;

  // 1. Photo Puce (DG2)
  if (cleanRecord.photo && cleanRecord.photo.base64) {
    const mime = cleanRecord.photo.mimeType || 'image/jpeg';
    $('photoBox').outerHTML = `<img class="photo" id="photoBox" alt="Photo Puce (DG2)" src="data:${esc(mime)};base64,${cleanRecord.photo.base64}">`;
  } else {
    $('photoBox').outerHTML = `<div class="photo" id="photoBox">Photo non lue</div>`;
  }

  // 2. Noms & NIN
  const nameLat = [h.lastNameLatin, h.firstNameLatin].filter(Boolean).join(' ') || '—';
  const nameAr = [h.lastNameArabic, h.firstNameArabic].filter(Boolean).join(' ') || '';
  $('nameLatin').textContent = nameLat;
  $('nameArabic').textContent = nameAr;
  $('nin').textContent = h.nin ? `NIN ${h.nin}` : 'NIN non disponible';

  // 3. Badges cryptographiques de la puce uniquement
  const labels: Record<string, string> = {
    dataIntegrity: 'Intégrité',
    signature: 'Signature SOD',
    certificateChain: 'Chaîne CSCA',
  };
  let badgesHtml = '';
  if (v.accessMethod) {
    badgesHtml += `<span class="badge VALID">Accès ${esc(v.accessMethod)}</span>`;
  }
  for (const [k, label] of Object.entries(labels)) {
    if (pa[k]) {
      badgesHtml += `<span class="badge ${esc(pa[k])}">${label} : ${esc(frStatus(pa[k]))}</span>`;
    }
  }
  if (aa.result) {
    badgesHtml += `<span class="badge ${esc(aa.result)}">Anti-clonage : ${esc(frStatus(aa.result))}</span>`;
  }
  $('badges').innerHTML = badgesHtml;

  // 4. Résumés cryptographiques
  const setSummary = (id: string, text?: string, isBad?: boolean) => {
    const el = $(id);
    if (text) {
      el.textContent = text;
      el.className = 'summary' + (isBad ? ' bad' : '');
      el.style.display = 'block';
    } else {
      el.style.display = 'none';
    }
  };
  setSummary('paSummary', pa.summary, (pa.summary || '').startsWith('ALERTE'));
  setSummary('aaSummary', aa.summary, aa.result === 'INVALID');

  // 5. Champs détaillés (Titulaire + Document + Signature)
  const bi = (lat?: string, ar?: string) =>
    esc(lat || '—') + (ar ? `<span class="ar">${esc(ar)}</span>` : '');

  const sig = cleanRecord.signatureImage;
  const sigHtml =
    sig && sig.base64
      ? `<img alt="Signature du titulaire" style="max-width:240px;max-height:85px;background:#fff;border-radius:6px;padding:4px" src="data:${esc(sig.mimeType || 'image/jpeg')};base64,${sig.base64}">`
      : '';

  const rows: Array<[string, string]> = [
    ['Date de naissance', esc(h.dateOfBirth || '—')],
    ['Lieu de naissance', bi(h.placeOfBirthLatin, h.placeOfBirthArabic)],
    ['Sexe', bi(h.sex === 'M' ? 'Masculin' : h.sex === 'F' ? 'Féminin' : h.sex, h.sexArabic)],
    ['Groupe sanguin', esc(h.bloodGroup || '—')],
    ['Nationalité', esc(h.nationality || '—')],
    ['Adresse', esc(h.address || '—')],
    ['Document', bi(d.nameLatin || d.type, d.nameArabic)],
    ['N° du document', esc(d.number || '—')],
    ['Délivré le', esc(d.dateOfIssue || '—')],
    ['Expire le', esc(d.dateOfExpiry || '—')],
    ['Autorité', bi(d.issuingAuthorityLatin, d.issuingAuthorityArabic)],
  ];
  if (sigHtml) {
    rows.push(['Signature manuscrite (DG7)', sigHtml]);
  }

  $('fields').innerHTML = rows
    .map(([k, val]) => `<div class="field"><div class="k">${k}</div><div class="v">${val || '—'}</div></div>`)
    .join('');

  // 6. Pré-remplissage du formulaire métier (ex. Frida / ERP)
  ($('f_nom') as HTMLInputElement).value = h.lastNameLatin || '';
  ($('f_prenom') as HTMLInputElement).value = h.firstNameLatin || '';
  ($('f_nom_ar') as HTMLInputElement).value = nameAr;
  ($('f_nin') as HTMLInputElement).value = h.nin || '';
  ($('f_doc') as HTMLInputElement).value = `${d.number || '—'} (exp. ${d.dateOfExpiry || '—'})`;
  ($('f_naissance') as HTMLInputElement).value = `${h.dateOfBirth || '—'} — ${h.placeOfBirthLatin || ''}`.trim();
  const kycParts = [
    pa.dataIntegrity === 'VALID' ? 'Puce authentique (DG/SOD)' : 'Puce lue',
    aa.result === 'VALID' ? 'Anti-clonage OK' : null,
  ].filter(Boolean);
  ($('f_statut') as HTMLInputElement).value = kycParts.join(' · ');
  ($('f_date') as HTMLInputElement).value = nowStr;

  // 7. JSON complet + version tronquée pour l'affichage
  const dossier = {
    receivedAt: new Date().toISOString(),
    sessionId,
    ...cleanRecord,
  };
  currentFullJson = JSON.stringify(dossier, null, 2);

  const shown = JSON.parse(currentFullJson);
  for (const k of ['photo', 'signatureImage']) {
    if (shown[k] && shown[k].base64) {
      shown[k].base64 = `${shown[k].base64.substring(0, 60)}… (${dossier[k].base64.length} caractères)`;
    }
  }
  $('json').textContent = JSON.stringify(shown, null, 2);
}

async function startSession() {
  try {
    $('relayDot').className = 'dot wait';
    $('relayStatusText').textContent = 'Ouverture de session…';
    $('loader').textContent = '⏳ Génération de la clé ECDH P-256 et du QR Code…';

    const relayUrl = 'http://localhost:3000';
    const session = new DzEidSession(relayUrl);

    const qrDataUrl = await session.initSessionAndGetQrCode();

    $('relayDot').className = 'dot ok';
    $('relayStatusText').textContent = 'Relais E2EE prêt';

    $('qr-container').innerHTML = `
      <img src="${qrDataUrl}" alt="QR Code de connexion" />
      <div class="relay-url">
        Passerelle mobile : <code>${esc(session.mobileRelayUrl)}</code>
      </div>
    `;
    $('loader').textContent = '📱 En attente du scan QR et de la lecture NFC sur le téléphone…';

    const record = await session.waitForCardData();
    $('loader').innerHTML = '✅ <b>Identité reçue et déchiffrée avec succès !</b>';
    renderRecord(record, session.sessionId || 'local');
  } catch (error) {
    console.error('Erreur lors de la session :', error);
    $('relayDot').className = 'dot ko';
    $('relayStatusText').textContent = 'Relais injoignable';
    $('loader').textContent = '❌ Erreur de connexion au relais (vérifiez le port 3000).';
  }
}

$('newSessionBtn').addEventListener('click', () => startSession());

$('printKycBtn').addEventListener('click', () => {
  window.print();
});

$('downloadJsonBtn').addEventListener('click', () => {
  if (!currentFullJson || !currentRecord) return;
  const h = currentRecord.holder || {};
  const d = currentRecord.document || {};
  const idPart = (h.lastNameLatin || d.number || 'identite').replace(/[^A-Za-z0-9_-]/g, '_');
  const stamp = new Date().toISOString().replace(/[^0-9]/g, '').substring(0, 14);
  const blob = new Blob([currentFullJson], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `identite-${idPart}-${stamp}.dzeid.json`;
  a.click();
  URL.revokeObjectURL(a.href);
});

$('toggleFormBtn').addEventListener('click', () => {
  const panel = $('kycFormPanel');
  panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
});

$('copyJsonBtn').addEventListener('click', async () => {
  if (!currentFullJson) return;
  await navigator.clipboard.writeText(currentFullJson);
  const btn = $('copyJsonBtn');
  const prev = btn.textContent;
  btn.textContent = '✅ JSON copié !';
  setTimeout(() => { btn.textContent = prev; }, 2000);
});

startSession();
