package com.muhend.backendai.config.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;

@Profile("!calc-only")
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class WebSecurityConfig {

    private final UserDetailsServiceImpl userDetailsService;
    private final DemoAuthFilter demoAuthFilter;

    public WebSecurityConfig(UserDetailsServiceImpl userDetailsService, DemoAuthFilter demoAuthFilter) {
        this.userDetailsService = userDetailsService;
        this.demoAuthFilter = demoAuthFilter;
    }

    @Bean
    public JwtAuthFilter authenticationJwtTokenFilter() {
        return new JwtAuthFilter();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();

        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());

        return authProvider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .csrf(csrf -> csrf.disable())
            // Sans jeton valide (absent, expiré, autre clé) : 401, et non 403 réservé aux droits
            // insuffisants. Le frontend renvoie alors à la page de connexion.
            .exceptionHandling(exceptions -> exceptions
                    .authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)))
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> 
                auth.requestMatchers("/api/auth/**", "/api/calculs/**", "/api/brouillons/**", "/api/frida/*/word", "/api/frida/*/pdf").permitAll()
                    .requestMatchers("/v3/api-docs/**", "/api-docs/**", "/swagger-ui/**", "/swagger-ui.html").permitAll()
                    // Test de santé Docker (HEALTHCHECK du backend) : sans jeton, sinon 403 et conteneur « unhealthy »
                    .requestMatchers("/actuator/health", "/actuator/health/**").permitAll()
                    // Sessions NFC : ouvertes au Mobile (upload) et au SSE (EventSource ne supportant pas le header Authorization)
                    .requestMatchers("/api/nfc-session/**").permitAll()
                    // OCR CNI recto : appelé par le mobile sans token
                    .requestMatchers("/api/pdfs/ocr-cni-front").permitAll()
                    // Liens de téléchargement à usage unique, créés par un compte Maître (TelechargementService)
                    .requestMatchers(HttpMethod.GET, "/api/telechargements/*").permitAll()
                    // Page d'erreur interne : ne pas masquer une erreur par un 401
                    .requestMatchers("/error").permitAll()
                    .anyRequest().authenticated()
            );

        http.authenticationProvider(authenticationProvider());

        // Ordre : DemoAuthFilter (en premier) -> JwtAuthFilter (ensuite)
        http.addFilterBefore(demoAuthFilter, UsernamePasswordAuthenticationFilter.class);
        http.addFilterBefore(authenticationJwtTokenFilter(), DemoAuthFilter.class);

        return http.build();
    }

    @org.springframework.beans.factory.annotation.Value("${spring.web.cors.allowed-origin-patterns:http://localhost:4200,http://localhost:8080}")
    private String corsOrigins;

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        
        // Gérer plusieurs origines séparées par des virgules
        if (corsOrigins != null && !corsOrigins.isEmpty()) {
            configuration.setAllowedOriginPatterns(Arrays.asList(corsOrigins.split(",")));
        } else {
            configuration.setAllowedOriginPatterns(Arrays.asList("*"));
        }
        
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));
        configuration.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type", "X-Requested-With", "Accept", "Origin", "Access-Control-Request-Method", "Access-Control-Request-Headers"));
        configuration.setAllowCredentials(true);
        
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}
