import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UploadedFile, UploadConfig } from './file-upload.interface';
import { v4 as uuidv4 } from 'uuid';
import { FileUploadService } from '../../../services/file-upload.service';
import { NfcScannerModalComponent } from '../nfc-scanner-modal/nfc-scanner-modal.component';

@Component({
  selector: 'app-file-upload',
  standalone: true,
  imports: [CommonModule, FormsModule, NfcScannerModalComponent],
  template: `
    <div class="file-upload-layout" style="display: flex; gap: 20px; align-items: stretch; justify-content: center; max-width: 900px; margin: 0 auto; flex-wrap: wrap;">
      <!-- Colonne de gauche : Zone d'upload principale -->
      <div class="upload-container" style="flex: 1; min-width: 300px; max-width: 650px;">
        <h2>{{ config.title }}</h2>
        <div
          class="drop-zone"
          (dragover)="onDragOver($event)"
          (dragleave)="onDragLeave($event)"
          (click)="fileInput.click()"
          style="cursor: pointer;"
          [class.disabled-zone]="uploadedFiles.length >= (config.maxFiles || 10)"
        >
          <div class="drop-message" *ngIf="uploadedFiles.length < (config.maxFiles || 10)">
            <span class="material-icons">cloud_upload</span>
            <p>Glissez-déposez ou cliquez ici pour ajouter vos fichiers</p>
          </div>
          <div class="drop-message" *ngIf="uploadedFiles.length >= (config.maxFiles || 10)">
            <span class="material-icons" style="color: #ffb84d;">lock</span>
            <p style="color: #ffb84d;">Limite atteinte ({{ config.maxFiles }} max). Supprimez un fichier pour en ajouter un autre.</p>
          </div>
          <input
            #fileInput
            type="file"
            multiple
            style="display: none;"
            [disabled]="uploadedFiles.length >= (config.maxFiles || 10)"
            (change)="onFileSelected($event)"
          />
        </div>

        <div class="upload-actions" style="margin-top: 20px;">
          <div class="add-buttons" style="display: flex; gap: 10px; justify-content: center;" *ngIf="uploadedFiles.length < (config.maxFiles || 10)">
            <button class="btn btn-secondary" style="display: flex; align-items: center; justify-content: center; gap: 6px; flex: 1; max-width: 250px;" (click)="fileInput.click()">
              Sélectionner des fichiers
            </button>
            <button *ngIf="!isBeta" class="btn btn-primary" style="display: flex; align-items: center; justify-content: center; gap: 6px; flex: 1; max-width: 250px; background: #8b5cf6; border-color: #8b5cf6;" (click)="openScanner('mobile')">
              📱 Scanner (Mobile)
            </button>
            <button *ngIf="!isBeta" class="btn btn-primary" style="display: flex; align-items: center; justify-content: center; gap: 6px; flex: 1; max-width: 250px; background: #3b82f6; border-color: #3b82f6;" (click)="openScanner('usb')">
              🪪 Scanner (Lecteur USB)
            </button>
          </div>
        </div>

        <div class="file-list" *ngIf="uploadedFiles.length > 0" style="margin-top: 20px;">
          <div class="file-item" *ngFor="let file of uploadedFiles">
            <div class="file-info">
              <span class="material-icons">Document :</span>
              <span class="file-name" [title]="file.file.name">{{ file.file.name }} <span *ngIf="file.file.size === 0" style="background: rgba(78,204,163,0.2); color: #4ecca3; border: 1px solid #4ecca3; font-size: 0.7rem; padding: 2px 6px; border-radius: 4px; margin-left: 8px; vertical-align: middle;">✓ Sur le serveur</span></span>
              <select *ngIf="config.docTypes && config.docTypes.length > 0" [(ngModel)]="file.docType" (change)="onDocTypeChange(file)" class="select-doc-type file-select">
                <option *ngFor="let dt of config.docTypes" [value]="dt.id">{{ dt.label }}</option>
              </select>
              <select *ngIf="getEntitiesForDocType(file.docType).length > 0" [(ngModel)]="file.entityName" class="select-doc-type file-select">
                <option *ngFor="let ent of getEntitiesForDocType(file.docType)" [value]="ent">
                  {{ ent }} {{ ent === entiteDefaut(file.docType) ? '(par défaut)' : '' }}
                </option>
              </select>
            </div>
            <button class="btn-icon" (click)="removeFile(file.id)" aria-label="Supprimer le fichier">
              <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#D16D6A"><path d="M312-144q-29.7 0-50.85-21.15Q240-186.3 240-216v-480h-48v-72h192v-48h192v48h192v72h-48v479.57Q720-186 698.85-165T648-144H312Zm336-552H312v480h336v-480ZM384-288h72v-336h-72v336Zm120 0h72v-336h-72v336ZM312-696v480-480Z"/></svg>
            </button>
            <!-- Verso optionnel pour CNI -->
            <div class="verso-section" *ngIf="file.docType === 'cni'">
              <div class="verso-info" *ngIf="file.versoFile">
                <span class="verso-badge" style="display: flex; align-items: center; gap: 4px;">
                  <span class="material-icons" style="font-size: 1rem;">content_paste</span> Verso :
                </span>
                <span class="file-name">{{ file.versoFile.name }}</span>
                <button class="btn-icon btn-sm" (click)="removeVerso(file.id)" aria-label="Supprimer verso">
                  <span class="material-icons" style="font-size: 1.2rem;">close</span>
                </button>
              </div>
              <button class="btn btn-verso" *ngIf="!file.versoFile" (click)="triggerVersoInput(file.id)">
                + Ajouter verso (optionnel)
              </button>
              <input [id]="'verso_' + file.id" type="file" style="display:none" [accept]="config.allowedTypes.join(',')" (change)="onVersoSelected($event, file.id)" />
            </div>
          </div>
        </div>
      </div>

      <!-- Colonne de droite : Boutons de navigation empilés -->
      <div class="nav-sidebar" style="display: flex; flex-direction: column; gap: 12px; width: 250px; padding-top: 55px;" *ngIf="uploadedFiles.length > 0 || config.allowPrevious || config.allowSkip || !isBeta">
        
        <button class="btn btn-primary" style="width: 100%; justify-content: center; padding: 12px;" (click)="onUpload()" *ngIf="uploadedFiles.length > 0">
          Suivant
        </button>

        <button class="btn" style="width: 100%; justify-content: center; padding: 12px;" [ngClass]="config.highlightSkip ? 'btn-primary' : 'btn-secondary'" (click)="onSkip()" *ngIf="uploadedFiles.length === 0 && config.allowSkip">
          {{ config.skipText || 'Continuer' }}
        </button>

        <button class="btn btn-secondary" style="width: 100%; justify-content: center; padding: 12px;" *ngIf="config.allowPrevious" (click)="onPrevious()">
          Précédent
        </button>

        <!-- Slot pour les boutons globaux passés par le parent -->
        <ng-content select="[global-actions]"></ng-content>

      </div>

      <!-- Modale de Scanner NFC -->
      <app-nfc-scanner-modal 
        *ngIf="showNfcModal" 
        [mode]="scannerMode"
        (closeModal)="showNfcModal = false" 
        (nfcDataReceived)="onNfcDataReceived($event)">
      </app-nfc-scanner-modal>
    </div>
  `,
  styles: [`
    .material-symbols-outlined {
      font-variation-settings:
          'FILL' 0,
          'wght' 400,
          'GRAD' 0,
          'opsz' 24
    }
    
    .upload-container {
      padding: var(--spacing-xs);
    }
    
    .upload-container h2 {
      text-align: center;
      font-size: 1.8rem;
      color: var(--accent-color);
      margin-bottom: var(--spacing-sm);
      text-transform: uppercase;
      letter-spacing: 1px;
      font-weight: bold;
    }

    .doc-type-selector {
      display: flex;
      align-items: center;
      gap: var(--spacing-xs);
      margin-bottom: var(--spacing-xs);
    }

    .select-doc-type {
      padding: 6px 12px;
      border: 1px solid var(--accent-color);
      border-radius: var(--border-radius);
      background: rgba(78, 204, 163, 0.05);
      color: inherit;
      font-size: 0.95rem;
    }

    /* Correction du bug d'affichage blanc sur blanc pour les options */
    .select-doc-type option {
      background-color: #2c3e50; /* Couleur foncée par défaut pour s'assortir au thème sombre probable */
      color: #ffffff;
    }
    
    .drop-zone {
      border: 2px dashed var(--accent-color);
      border-radius: var(--border-radius);
      padding: var(--spacing-xs);
      text-align: center;
      transition: var(--transition);
      background: rgba(78, 204, 163, 0.05);
    }
    
    .drop-zone.drag-over:not(.disabled-zone) {
      background: rgba(78, 204, 163, 0.1);
      border-color: var(--accent-color);
    }
    
    .drop-zone.disabled-zone {
      opacity: 0.6;
      cursor: default;
      background: rgba(0, 0, 0, 0.2);
      border-color: rgba(255, 255, 255, 0.1);
    }
    .drop-zone.disabled-zone .btn {
      pointer-events: auto;
      opacity: 1;
      cursor: pointer;
    }
    
    .file-list {
      margin-top: var(--spacing-xs);
    }
    
    .file-item {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
      gap: var(--space-2);
      padding: var(--spacing-xs);
      background: rgba(78, 204, 163, 0.05);
      border-radius: var(--border-radius);
      margin-bottom: var(--spacing-xs);
    }

    /* Le contenu passe à la ligne au lieu de déborder : sinon la corbeille glissait
       sous la colonne des boutons de navigation et ne recevait plus les clics. */
    .file-info {
      display: flex;
      flex: 1;
      flex-wrap: wrap;
      align-items: center;
      gap: var(--spacing-xs);
      min-width: 0;
    }

    .file-name {
      min-width: 0;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .file-item > .btn-icon {
      flex-shrink: 0;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border: none;
      border-radius: var(--radius-sm);
      background: transparent;
      cursor: pointer;
      transition: background var(--duree-rapide);
    }

    .file-item > .btn-icon:hover {
      background: var(--danger-soft);
    }

    .file-item > .verso-section {
      flex-basis: 100%;
    }
    
    .button-group {
      display: flex;
      gap: var(--spacing-xs);
      margin-top: var(--spacing-xs);
      justify-content: flex-end;
    }
    
    .file-select {
      max-width: 100%;
      padding: 4px 8px;
    }

    .verso-section {
      padding: 4px 12px 8px 32px;
    }

    .btn-verso {
      background: transparent;
      border: 1px dashed rgba(78, 204, 163, 0.4);
      color: var(--accent-color);
      padding: 4px 12px;
      border-radius: var(--border-radius);
      font-size: 0.8rem;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .btn-verso:hover {
      background: rgba(78, 204, 163, 0.1);
      border-color: var(--accent-color);
    }

    .verso-info {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 0.85rem;
    }

    .verso-badge {
      color: var(--accent-color);
      font-weight: bold;
    }

    .btn-sm {
      font-size: 0.75rem;
      padding: 2px 6px;
      color: #D16D6A;
      background: none;
      border: none;
      cursor: pointer;
    }
  `]
})
export class FileUploadComponent implements OnInit {
  @Input() config!: UploadConfig & { allowPrevious?: boolean };
  @Input() initialFiles: UploadedFile[] = [];
  
  @Output() filesConfirmed = new EventEmitter<{rawFiles: UploadedFile[], groupedFiles: {files: File[], docType: string, entityName: string}[]}>();
  @Output() previousClicked = new EventEmitter<void>();
  @Output() uploadCancelled = new EventEmitter<void>();
  @Output() pendingFilesChanged = new EventEmitter<number>();
  @Output() skipClicked = new EventEmitter<void>();

  uploadedFiles: UploadedFile[] = [];
  
  get isBeta(): boolean {
    return window.location.hostname.includes('frida.enclume-numerique.com');
  }

  showNfcModal: boolean = false;
  scannerMode: 'mobile' | 'usb' = 'mobile';

  openScanner(mode: 'mobile' | 'usb') {
    this.scannerMode = mode;
    this.showNfcModal = true;
  }

  /** Entité OCR proposée par défaut, par type de document (sinon {type}_01). */
  private readonly entitesParDefaut: Record<string, string> = {
    en: 'en_01_qrcode_01',
    ad: 'adc_01'
  };

  entiteDefaut(docType: string): string {
    return this.entitesParDefaut[docType] || docType + '_01';
  }

  availableEntities: Record<string, string[]> = {
    'cni': [],
    'en': [],
    'pp': []
  };

  constructor(private fileUploadService: FileUploadService) {}

  getEntitiesForDocType(docType: string): string[] {
    return this.availableEntities[docType] || [];
  }

  ngOnInit() {
    if (this.initialFiles && this.initialFiles.length > 0) {
      this.uploadedFiles = [...this.initialFiles];
      // Pour s'assurer que le parent a bien le compte initial quand on revient en arrière
      setTimeout(() => this.pendingFilesChanged.emit(this.uploadedFiles.length));
    }
    
    // Charger dynamiquement les entités OCR depuis l'API Python
    this.fileUploadService.getEntities().subscribe({
      next: (entities) => {
        const cni = entities.filter(e => e.nom && e.nom.startsWith('cni_')).map(e => e.nom);
        const en = entities.filter(e => e.nom && e.nom.startsWith('en_')).map(e => e.nom);
        const pp = entities.filter(e => e.nom && e.nom.startsWith('pp_')).map(e => e.nom);
        this.availableEntities = { 'cni': cni, 'en': en, 'pp': pp };
      },
      error: (err) => console.error("Erreur de chargement des entités OCR", err)
    });
  }

  getFileSize(bytes: number): string {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  onDragOver(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    const dropZone = event.currentTarget as HTMLElement;
    dropZone.classList.add('drag-over');
  }

  onDragLeave(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    const dropZone = event.currentTarget as HTMLElement;
    dropZone.classList.remove('drag-over');
  }

  onDrop(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    const dropZone = event.currentTarget as HTMLElement;
    dropZone.classList.remove('drag-over');

    const files = event.dataTransfer?.files;
    if (files) {
      this.addFiles(Array.from(files));
    }
  }

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.addFiles(Array.from(input.files));
      input.value = ''; // Réinitialiser pour permettre de resélectionner le même fichier
    }
  }

  addFiles(newFiles: File[]) {
    const validFiles = newFiles.filter(file => this.validateFile(file));

    validFiles.forEach(file => {
      const docType = this.config.defaultDocType || (this.config.docTypes && this.config.docTypes.length > 0 ? this.config.docTypes[0].id : 'en');
      this.uploadedFiles.push({
        file,
        id: uuidv4(),
        progress: 0,
        docType: docType,
        entityName: this.entiteDefaut(docType)
      });
    });
    this.pendingFilesChanged.emit(this.uploadedFiles.length);
  }

  onDocTypeChange(file: UploadedFile) {
    file.entityName = this.entiteDefaut(file.docType);
  }

  validateFile(file: File): boolean {
    if (file.size > this.config.maxFileSize) {
      // Ajouter un message d'erreur
      return false;
    }

    if (!this.config.allowedTypes.includes(file.type)) {
      // Ajouter un message d'erreur
      return false;
    }

    return true;
  }

  removeFile(id: string) {
    this.uploadedFiles = this.uploadedFiles.filter(file => file.id !== id);
    this.pendingFilesChanged.emit(this.uploadedFiles.length);
    if (this.uploadedFiles.length === 0) {
      this.uploadCancelled.emit();
    }
  }

  onCancel() {
    this.uploadedFiles = [];
    this.pendingFilesChanged.emit(0);
    this.uploadCancelled.emit();
  }

  onPrevious() {
    this.previousClicked.emit();
  }

  onSkip() {
    this.skipClicked.emit();
  }

  triggerVersoInput(fileId: string) {
    const input = document.getElementById('verso_' + fileId) as HTMLInputElement;
    if (input) input.click();
  }

  onVersoSelected(event: Event, fileId: string) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const versoFile = input.files[0];
      const target = this.uploadedFiles.find(f => f.id === fileId);
      if (target) {
        target.versoFile = versoFile;
      }
      input.value = '';
    }
  }

  removeVerso(fileId: string) {
    const target = this.uploadedFiles.find(f => f.id === fileId);
    if (target) {
      target.versoFile = undefined;
    }
  }

  onUpload() {
    if (this.uploadedFiles.length > 0) {
      // Group files by docType and entityName
      const groups = new Map<string, {files: File[], docType: string, entityName: string}>();

      this.uploadedFiles.forEach(f => {
        const key = f.docType + '_' + (f.entityName || '');
        if (!groups.has(key)) {
          groups.set(key, {files: [], docType: f.docType, entityName: f.entityName || ''});
        }
        groups.get(key)!.files.push(f.file);

        // Si un verso est attaché, le mettre dans un groupe séparé avec le suffixe '_verso'
        if (f.versoFile) {
          const versoKey = key + '_verso';
          // Renommer le fichier avec le suffixe _verso pour la détection côté backend
          // Nom derive du RECTO, pas du verso : le backend apparie recto et verso par nom
          // de base. C'est le seul lien fiable quand plusieurs personnes d'une meme
          // categorie (ex. deux fils) fournissent chacune une CNI.
          const rectoBase = f.file.name.replace(/\.\w+$/, '');
          const versoExt = (f.versoFile.name.match(/\.\w+$/) || [''])[0];
          const renamedVerso = new File([f.versoFile], rectoBase + '_verso' + versoExt, { type: f.versoFile.type });
          if (!groups.has(versoKey)) {
            groups.set(versoKey, {files: [], docType: f.docType, entityName: (f.entityName || '') + '_verso'});
          }
          groups.get(versoKey)!.files.push(renamedVerso);
        }
      });

      // Emit array of groups
      const emitData: { files: File[], docType: string, entityName: string }[] = [];
      groups.forEach((groupData, key) => {
        emitData.push(groupData);
      });

      this.filesConfirmed.emit({
        rawFiles: [...this.uploadedFiles],
        groupedFiles: emitData
      });
    }
  }

  onNfcDataReceived(data: any) {
    console.log("Données NFC reçues dans le formulaire !", data);
    // On convertit le JSON NFC reçu en un "fichier" virtuel JSON pour l'upload
    // Le nom de fichier permettra au backend de l'identifier comme un dump NFC
    const jsonString = JSON.stringify(data);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const virtualFile = new File([blob], `nfc_dump_${data.documentNumber || uuidv4()}.json`, { type: 'application/json' });
    
    // On simule l'ajout de ce fichier comme une CNI
    this.uploadedFiles.push({
      file: virtualFile,
      id: uuidv4(),
      progress: 0,
      docType: 'cni',
      entityName: 'cni_01'
    });
    this.pendingFilesChanged.emit(this.uploadedFiles.length);
    
    // Facultatif : on pourrait même déclencher le "Suivant" automatiquement
    // this.onUpload();
  }
}




