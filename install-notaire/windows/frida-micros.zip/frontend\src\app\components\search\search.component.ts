import { NotificationService } from '../../services/notification.service';
import { Component, OnInit, inject } from '@angular/core';
import { FridaService } from '../../services/frida.service';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { BrouillonService, Brouillon } from '../../services/brouillon.service';

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="list-wrapper">
      <div class="glass-panel">
        <div style="display: flex; gap: 0; margin-bottom: 1rem;">
          <button (click)="activeTab = 'fridas'" 
            [style.background]="activeTab === 'fridas' ? '#4ecca3' : 'transparent'"
            [style.color]="activeTab === 'fridas' ? '#1e293b' : '#a0aec0'"
            style="padding: 8px 20px; border: 1px solid #4ecca3; border-radius: 8px 0 0 8px; cursor: pointer; font-weight: 600;">
            Fridas validées
          </button>
          <button (click)="activeTab = 'brouillons'" 
            [style.background]="activeTab === 'brouillons' ? '#4ecca3' : 'transparent'"
            [style.color]="activeTab === 'brouillons' ? '#1e293b' : '#a0aec0'"
            style="padding: 8px 20px; border: 1px solid #4ecca3; border-radius: 0 8px 8px 0; cursor: pointer; font-weight: 600;">
            Brouillons ({{ brouillons.length }})
          </button>
        </div>

        <div *ngIf="activeTab === 'fridas'">
          <div class="header-section">
            <h2>Rechercher</h2>
            <div class="search-box">
              <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor"><path d="M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z"/></svg>
              <input type="text" placeholder="Rechercher par nom, numéro ou date..." [value]="termeRecherche" (input)="onSearch($event)" />
            </div>
          </div>

          <div class="stats-bar" *ngIf="fridaList.length > 0" style="display: flex; gap: 1rem; align-items: center;">
            <span class="stat-chip">{{ filteredList.length }} dossier{{ filteredList.length > 1 ? 's' : '' }}</span>
            <button *ngIf="testCount > 0" class="btn-delete-tests" (click)="deleteAllTests()">
              <svg xmlns="http://www.w3.org/2000/svg" height="18" viewBox="0 -960 960 960" width="18" fill="currentColor"><path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z"/></svg>
              Supprimer les {{ testCount }} Tests
            </button>
          </div>

          <div class="table-container">
            <table class="table">
              <thead>
                <tr>
                  <th (click)="sort('numFrida')" class="sortable">
                    Numéro de Dossier
                    <span class="sort-icon">{{ getSortIcon('numFrida') }}</span>
                  </th>
                  <th (click)="sort('nom')" class="sortable">
                    Défunt (Nom Prénom)
                    <span class="sort-icon">{{ getSortIcon('nom') }}</span>
                  </th>
                  <th (click)="sort('dateCreation')" class="sortable">
                    Date de Création
                    <span class="sort-icon">{{ getSortIcon('dateCreation') }}</span>
                  </th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let frida of filteredList" [class.row-test]="isTest(frida)">
                  <td class="font-mono">
                    <strong>{{ frida?.numFrida }}</strong>
                    <span *ngIf="isTest(frida)" class="badge-test" style="margin-left: 8px;">🛠️ Test Auto</span>
                    <span *ngIf="frida?.requiresCorrection && frida?.statut === 'EN_ATTENTE_REVISION'" class="badge-warning" style="margin-left: 8px;">⚠️ À corriger</span>
                    <span *ngIf="frida?.requiresCorrection && frida?.statut === 'BROUILLON'" class="badge-warning" style="margin-left: 8px; background: rgba(236, 201, 75, 0.15); color: #ecc94b; border-color: rgba(236, 201, 75, 0.3);">⏳ En attente</span>
                  </td>
                  <td><span class="demo-blur">{{ frida?.nom }}</span> {{ frida?.prenom }}</td>
                  <td><span class="badge">{{ frida?.dateCreation }}</span></td>
                  <td>
                    <div class="actions-container">
                      <button class="btn-action" 
                              (click)="voirFrida(frida.numFrida, frida.requiresCorrection && (frida.statut === 'EN_ATTENTE_REVISION' || frida.statut === 'BROUILLON'))" 
                              [title]="(frida.requiresCorrection && (frida.statut === 'EN_ATTENTE_REVISION' || frida.statut === 'BROUILLON')) ? 'Corriger les données' : 'Consulter l\\'acte'">
                        <svg *ngIf="!(frida.requiresCorrection && (frida.statut === 'EN_ATTENTE_REVISION' || frida.statut === 'BROUILLON'))" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h560v-280h80v280q0 33-23.5 56.5T760-120H200Zm188-212-56-56 372-372H560v-80h280v280h-80v-144L388-332Z"/></svg>
                        <svg *ngIf="frida.requiresCorrection && (frida.statut === 'EN_ATTENTE_REVISION' || frida.statut === 'BROUILLON')" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor"><path d="M200-200h57l391-391-57-57-391 391v57Zm-80 80v-170l528-527q12-11 26.5-17t30.5-6q16 0 31 6t26 18l55 56q11 11 17 25.5t6 30.5q0 16-6 30.5t-17 25.5L290-120H120Zm640-584-56-56 56 56Zm-141 85-28-29 57 57-29-28Z"/></svg>
                        <span>{{ (frida.requiresCorrection && (frida.statut === 'EN_ATTENTE_REVISION' || frida.statut === 'BROUILLON')) ? 'Corriger' : 'Ouvrir' }}</span>
                      </button>
                      <button class="btn-delete" (click)="deleteFrida(frida.numFrida)" title="Supprimer la Frida">
                        <svg xmlns="http://www.w3.org/2000/svg" height="20" viewBox="0 -960 960 960" width="20" fill="currentColor"><path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z"/></svg>
                      </button>
                    </div>
                  </td>
                </tr>
                <tr *ngIf="filteredList.length === 0">
                  <td colspan="4" class="empty-state">
                    Aucun document trouvé pour cette recherche.
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div *ngIf="activeTab === 'brouillons'">
          <table *ngIf="brouillons.length > 0" style="width: 100%; border-collapse: collapse;">
            <thead>
              <tr style="border-bottom: 2px solid rgba(78,204,163,0.3);">
                <th style="padding: 10px; text-align: left; color: #4ecca3;">Nom</th>
                <th style="padding: 10px; text-align: left; color: #4ecca3;">Prénom</th>
                <th style="padding: 10px; text-align: left; color: #4ecca3;">Date création</th>
                <th style="padding: 10px; text-align: left; color: #4ecca3;">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let b of brouillons" style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                <td style="padding: 10px;">{{ b.nomDefunt }}</td>
                <td style="padding: 10px;">{{ b.prenomDefunt }}</td>
                <td style="padding: 10px;">{{ b.dateCreation }}</td>
                <td style="padding: 10px;">
                  <button (click)="reprendreBrouillon(b)" style="padding: 5px 15px; background: #4ecca3; color: #1e293b; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; margin-right: 8px;">Reprendre</button>
                  <button (click)="supprimerBrouillon(b)" style="padding: 5px 15px; background: transparent; color: #D16D6A; border: 1px solid #D16D6A; border-radius: 6px; cursor: pointer;">Supprimer</button>
                </td>
              </tr>
            </tbody>
          </table>
          <p *ngIf="brouillons.length === 0" style="text-align: center; color: #a0aec0; padding: 2rem;">Aucun brouillon en cours</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .list-wrapper {
      min-height: calc(100vh - 80px);
      padding: 3rem 2rem;
      background: #0f1c15;
      display: flex;
      justify-content: center;
      align-items: flex-start;
      animation: fadeIn 0.8s ease-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .glass-panel {
      background: rgba(255, 255, 255, 0.03);
      backdrop-filter: blur(16px);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 16px;
      padding: 2rem;
      width: 100%;
      max-width: 1100px;
      box-shadow: 0 15px 35px rgba(0,0,0,0.4);
    }

    .header-section {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.2rem;
      flex-wrap: wrap;
      gap: 1rem;
    }

    h2 {
      color: #ffffff;
      margin: 0;
      font-size: 2rem;
    }

    .search-box {
      display: flex;
      align-items: center;
      background: rgba(0, 0, 0, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 8px;
      padding: 0.5rem 1rem;
      width: 100%;
      max-width: 400px;
      transition: all 0.3s ease;
    }
    
    .search-box:focus-within {
      border-color: #48bb78;
      box-shadow: 0 0 0 2px rgba(72, 187, 120, 0.2);
    }

    .search-box svg {
      color: #a0aec0;
      margin-right: 0.5rem;
      flex-shrink: 0;
    }

    .search-box input {
      background: transparent;
      border: none;
      color: #fff;
      font-size: 1rem;
      width: 100%;
      outline: none;
    }

    .stats-bar {
      margin-bottom: 1rem;
    }

    .stat-chip {
      background: rgba(72, 187, 120, 0.1);
      color: #68d391;
      padding: 0.3rem 0.8rem;
      border-radius: 20px;
      font-size: 0.85rem;
      font-weight: 500;
    }

    .table-container {
      overflow-x: auto;
    }

    .table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0;
      text-align: left;
    }

    .table th {
      padding: 1rem;
      color: #48bb78;
      background: rgba(0, 0, 0, 0.2);
      font-weight: 600;
      text-transform: uppercase;
      font-size: 0.9rem;
      letter-spacing: 0.05em;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .table th.sortable {
      cursor: pointer;
      user-select: none;
      transition: color 0.2s;
    }

    .table th.sortable:hover {
      color: #68d391;
    }

    .sort-icon {
      margin-left: 6px;
      font-size: 0.8rem;
      opacity: 0.7;
    }

    .table td {
      padding: 1rem;
      color: #e2e8f0;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
      vertical-align: middle;
    }

    .table tbody tr {
      transition: background-color 0.2s ease;
    }

    .table tbody tr:hover {
      background: rgba(255, 255, 255, 0.05);
    }

    .font-mono {
      font-family: monospace;
      letter-spacing: 1px;
      color: #63b3ed;
    }

    .badge {
      background: rgba(72, 187, 120, 0.15);
      color: #48bb78;
      padding: 0.25rem 0.75rem;
      border-radius: 9999px;
      font-size: 0.85rem;
      font-weight: 500;
    }

    .badge-warning {
      background: rgba(237, 137, 54, 0.15);
      color: #ed8936;
      border: 1px solid rgba(237, 137, 54, 0.3);
      padding: 0.2rem 0.5rem;
      border-radius: 6px;
      font-size: 0.75rem;
      font-weight: bold;
    }

    .badge-test {
      background: rgba(159, 122, 234, 0.15);
      color: #b794f4;
      border: 1px solid rgba(159, 122, 234, 0.3);
      padding: 0.2rem 0.5rem;
      border-radius: 6px;
      font-size: 0.75rem;
      font-weight: bold;
    }

    .table tbody tr.row-test {
      background: rgba(159, 122, 234, 0.05);
    }
    .table tbody tr.row-test:hover {
      background: rgba(159, 122, 234, 0.1);
    }

    .btn-action {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      background: rgba(66, 153, 225, 0.15);
      color: #63b3ed;
      border: 1px solid rgba(66, 153, 225, 0.3);
      padding: 0.5rem 1rem;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 500;
      transition: all 0.2s;
    }

    .actions-container {
      display: flex;
      gap: 0.5rem;
      align-items: center;
    }

    .btn-action:hover {
      background: rgba(66, 153, 225, 0.3);
      color: #fff;
    }

    .btn-delete {
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(245, 101, 101, 0.15);
      color: #fc8181;
      border: 1px solid rgba(245, 101, 101, 0.3);
      padding: 0.5rem;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.2s;
    }

    .btn-delete:hover {
      background: rgba(245, 101, 101, 0.3);
      color: #fff;
    }

    .btn-delete-tests {
      display: flex;
      align-items: center;
      gap: 6px;
      background: rgba(245, 101, 101, 0.15);
      color: #fc8181;
      border: 1px solid rgba(245, 101, 101, 0.3);
      padding: 0.4rem 0.8rem;
      border-radius: 20px;
      cursor: pointer;
      font-size: 0.85rem;
      font-weight: 600;
      transition: all 0.2s;
    }

    .btn-delete-tests:hover {
      background: rgba(245, 101, 101, 0.3);
      color: #fff;
    }

    .empty-state {
      text-align: center;
      padding: 3rem !important;
      color: #a0aec0 !important;
      font-style: italic;
    }
  `]
})
export class SearchComponent implements OnInit {
  private notif = inject(NotificationService);
  private route = inject(ActivatedRoute);
  /** Terme saisi, conservé pour que le tri ne l'efface pas ; peut venir de l'accueil (?q=). */
  termeRecherche = '';
  fridaList: any[] = [];
  filteredList: any[] = [];
  brouillons: Brouillon[] = [];
  activeTab: 'fridas' | 'brouillons' = 'fridas';

  sortColumn: string = 'dateCreation';
  sortDirection: 'asc' | 'desc' = 'desc';

  constructor(private fridaService: FridaService, private brouillonService: BrouillonService, private router: Router) { }

  ngOnInit(): void {
    this.termeRecherche = this.route.snapshot.queryParamMap.get('q') ?? '';
    this.fridaService.lancerApi('/api/frida/fridas').subscribe({
      next: data => {
        if (data && Array.isArray(data)) {
          this.fridaList = data.filter(f => f != null);
          this.applySortAndFilter();
        }
      }
    });
    this.loadBrouillons();
  }

  loadBrouillons() {
    this.brouillonService.list().subscribe(data => {
      this.brouillons = data || [];
    });
  }

  reprendreBrouillon(b: Brouillon) {
    this.router.navigate(['/upload'], { queryParams: { brouillon: b.id, folderName: b.folderName } });
  }

  async supprimerBrouillon(b: Brouillon) {
    if (await this.notif.confirmer(`Supprimer le brouillon de ${b.nomDefunt} ?`, { titre: 'Supprimer le brouillon', libelleConfirmer: 'Supprimer', danger: true })) {
      this.brouillonService.delete(b.id).subscribe(() => {
        this.loadBrouillons();
      });
    }
  }

  onSearch(event: any) {
    this.termeRecherche = event.target.value;
    this.applySortAndFilter();
  }

  sort(column: string) {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = column === 'numFrida' || column === 'dateCreation' ? 'desc' : 'asc';
    }
    this.applySortAndFilter();
  }

  getSortIcon(column: string): string {
    if (this.sortColumn !== column) return '⇅';
    return this.sortDirection === 'asc' ? '▲' : '▼';
  }

  private applySortAndFilter(searchTerm: string = this.termeRecherche) {
    let list = [...this.fridaList];

    // Filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      list = list.filter(frida =>
        (frida.nom && frida.nom.toLowerCase().includes(term)) ||
        (frida.prenom && frida.prenom.toLowerCase().includes(term)) ||
        (frida.numFrida && frida.numFrida.toLowerCase().includes(term)) ||
        (frida.dateCreation && frida.dateCreation.includes(term))
      );
    }

    // Sort
    list.sort((a, b) => {
      const valA = (a[this.sortColumn] || '').toString().toLowerCase();
      const valB = (b[this.sortColumn] || '').toString().toLowerCase();
      const cmp = valA.localeCompare(valB);
      return this.sortDirection === 'asc' ? cmp : -cmp;
    });

    this.filteredList = list;
  }

  voirFrida(num: string, requiresCorrection?: boolean) {
    if (requiresCorrection) {
       this.router.navigate(['/edit', num]);
    } else {
       this.router.navigate(['/frida'], { queryParams: { numFrida: num } });
    }
  }

  async deleteFrida(numFrida: string) {
    if (await this.notif.confirmer(`Êtes-vous sûr de vouloir supprimer la Frida n° ${numFrida} ?`, { titre: 'Supprimer le dossier', libelleConfirmer: 'Supprimer', danger: true })) {
      this.fridaService.deleteFrida(numFrida).subscribe({
        next: () => {
          this.fridaList = this.fridaList.filter(f => f.numFrida !== numFrida);
          this.applySortAndFilter();
        },
        error: (err) => {
          console.error("Erreur lors de la suppression", err);
          this.notif.erreur("Une erreur est survenue lors de la suppression.");
        }
      });
    }
  }

  isTest(frida: any): boolean {
    return (frida?.nom && frida.nom.includes('[TEST]')) || 
           (frida?.prenom && frida.prenom.includes('SuperTest'));
  }

  get testCount(): number {
    return this.fridaList.filter(f => this.isTest(f)).length;
  }

  async deleteAllTests() {
    const tests = this.fridaList.filter(f => this.isTest(f));
    if (tests.length === 0) return;
    
    if (await this.notif.confirmer(`Êtes-vous sûr de vouloir supprimer définitivement les ${tests.length} dossiers de test ?`, { titre: 'Supprimer les dossiers de test', libelleConfirmer: 'Supprimer', danger: true })) {
      // Pour éviter de saturer l'API, on les supprime séquentiellement
      const deleteNext = (index: number) => {
        if (index >= tests.length) {
          this.applySortAndFilter();
          return;
        }
        const numFrida = tests[index].numFrida;
        this.fridaService.deleteFrida(numFrida).subscribe({
          next: () => {
            this.fridaList = this.fridaList.filter(f => f.numFrida !== numFrida);
            deleteNext(index + 1);
          },
          error: (err) => {
            console.error("Erreur lors de la suppression du test " + numFrida, err);
            // On continue quand même avec les autres
            deleteNext(index + 1);
          }
        });
      };
      
      deleteNext(0);
    }
  }
}
