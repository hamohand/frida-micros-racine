package com.muhend.backendai.controller.dossier;

import com.muhend.backendai.dto.dossier.CreateFolderRequest;
import com.muhend.backendai.dto.dossier.FolderResponse;
import com.muhend.backendai.service.dossier.FolderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Profile("!calc-only")
@RestController
@RequestMapping("/api/folders")
@RequiredArgsConstructor
@Tag(name = "Folder Management", description = "API pour la gestion des dossiers")
public class FolderController {
    private final FolderService folderService;

    @PostMapping("/create")
    // @CrossOrigin(origins = "http://localhost:4200")
    @Operation(summary = "Créer un nouveau dossier", description = "Crée un dossier basé sur le nom et prénom fournis")
    public ResponseEntity<FolderResponse> createFolder(
            @Valid @RequestBody CreateFolderRequest request) {
        return ResponseEntity.ok(folderService.createFolder(request));
    }

    @DeleteMapping("/clear-latest")
    @Operation(summary = "Nettoyer le dossier", description = "Supprime les fichiers du dernier dossier pour éviter les doublons lors des re-vérifications")
    public ResponseEntity<Void> clearLatestFolder() {
        folderService.clearLatestFolder();
        return ResponseEntity.ok().build();
    }

    @GetMapping("/pending-batch")
    @Operation(summary = "Dossiers batch en attente", description = "Retourne la liste des dossiers non encore traités par le batch (sans fichier .processed)")
    public ResponseEntity<java.util.List<String>> getPendingBatchFolders() {
        return ResponseEntity.ok(folderService.getPendingBatchFolders());
    }
}