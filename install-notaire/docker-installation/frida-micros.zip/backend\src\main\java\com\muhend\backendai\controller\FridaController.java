package com.muhend.backendai.controller;

import com.muhend.backendai.dto.FridaDetailsDTO;
import com.muhend.backendai.dto.OcrCorrectionFieldDto;
import com.muhend.backendai.entities.FridaEntity;
import com.muhend.backendai.entities.HeritierEntity;
import com.muhend.backendai.entities.TemoinEntity;

import com.muhend.backendai.service.DefuntService;
import com.muhend.backendai.service.FridaService;
import com.muhend.backendai.service.HeritierService;
import com.muhend.backendai.service.TemoinService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Profile("!calc-only")
@RestController
@RequestMapping("/api/frida")
public class FridaController {
    @Autowired
    private final FridaService fridaService;

    @Autowired
    private HeritierService heritierService;
    @Autowired
    private TemoinService temoinService;
    @Autowired
    private DefuntService defuntService;

    public FridaController(FridaService fridaService) {
        this.fridaService = fridaService;
    }

    /**
     * Endpoint pour récupérer une fiche par numFrida
     * 
     * @param numFrida correspond au champ à rechercher
     * @return La fiche correspondante ou un statut 404 si elle n'existe pas
     */
    @GetMapping("/{numFrida}")
    public ResponseEntity<FridaEntity> getFridaByNumFrida(@PathVariable String numFrida) {
        Optional<FridaEntity> fridaEntity = fridaService.getFridaByNumFrida(numFrida);
        return fridaEntity.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Endpoint pour corriger une Frida, et relancer le calcul des parts.
     */
    @PutMapping("/corrections/{numFrida}")
    @org.springframework.security.access.prepost.PreAuthorize("hasRole('MAITRE')")
    public ResponseEntity<FridaEntity> corrigerFrida(@PathVariable String numFrida, @RequestBody FridaEntity corrections) {
        try {
            FridaEntity updatedFrida = fridaService.corrigerEtRecalculerFrida(numFrida, corrections);
            return ResponseEntity.ok(updatedFrida);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Retourne les champs OCR dont la confiance est inférieure au seuil (75%).
     * Utilisé par la fiche de correction avant validation.
     */
    @GetMapping("/champs-suspects/{numFrida}")
    public ResponseEntity<List<OcrCorrectionFieldDto>> getChampsSuspects(@PathVariable String numFrida) {
        List<OcrCorrectionFieldDto> champs = fridaService.getChampsSuspects(numFrida);
        return ResponseEntity.ok(champs);
    }

    /**
     * Applique les corrections manuelles champ par champ.
     */
    @PostMapping("/appliquer-corrections/{numFrida}")
    public ResponseEntity<Void> appliquerCorrections(
            @PathVariable String numFrida,
            @RequestBody List<Map<String, String>> corrections) {
        fridaService.appliquerCorrectionsOcr(numFrida, corrections);
        return ResponseEntity.ok().build();
    }

    /**
     * Met en attente les corrections sans valider le document.
     */
    @PostMapping("/mettre-en-attente/{numFrida}")
    public ResponseEntity<Void> mettreEnAttente(
            @PathVariable String numFrida,
            @RequestBody List<Map<String, String>> corrections) {
        fridaService.mettreEnAttenteOcr(numFrida, corrections);
        return ResponseEntity.ok().build();
    }

    // Affichage de certains champs (voir FridaDetailsDTO) de toutes les fridas
    @GetMapping("/fridas")
    public ResponseEntity<List<FridaDetailsDTO>> getFridas() {
        List<FridaDetailsDTO> fridaDetails = fridaService.getFridas();
        return ResponseEntity.ok(fridaDetails);
    }

    // Dossiers traités par le batch et en attente de révision humaine
    @GetMapping("/batch-en-attente")
    public ResponseEntity<List<FridaDetailsDTO>> getBatchEnAttente() {
        return ResponseEntity.ok(fridaService.getFridasEnAttente());
    }

    // Affiche les heritiers d'une frida par numFrida
    @GetMapping("/listeHeritiers/{numFrida}")
    public List<HeritierEntity> listeHeritiers(@PathVariable("numFrida") String numFrida) {
        return heritierService.listeHeritiers(numFrida);
    }

    // Affiche les témoins d'une frida par numFrida
    @GetMapping("/listeTemoins/{numFrida}")
    public List<TemoinEntity> listeTemoins(@PathVariable("numFrida") String numFrida) {
        return temoinService.listeTemoins(numFrida);
    }

    // Affiche les témoins d'une frida par nom
    @GetMapping("/listeDefunts/{nom}")
    public Optional<List<FridaDetailsDTO>> listeDefunts(@PathVariable("nom") String nom) {
        return defuntService.listeDefunts(nom);
    }

    /* ------------Non encore utilisés dans l'application---------------------- */
    @GetMapping("/search")
    public List<FridaDetailsDTO> getDefuntsByNom(@RequestParam String nom) {
        return fridaService.getFridaByNom(nom).orElse(List.of());
    }

    /**
     * Endpoint pour récupérer tout le contenu de la table Frida.
     * 
     * @return Liste des entités Frida.
     */
    @GetMapping("/all")
    public List<FridaEntity> getAllFridaEntities() {
        return fridaService.getAllFridaEntities();
    }

    /**
     * Endpoint pour supprimer une Frida et tous ses composants liés.
     * 
     * @param numFrida Le numéro de la frida à supprimer
     * @return 204 No Content si succès, 404 Not Found sinon
     */
    @DeleteMapping("/{numFrida}")
    public ResponseEntity<Void> deleteFrida(@PathVariable String numFrida) {
        boolean deleted = fridaService.deleteFrida(numFrida);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
